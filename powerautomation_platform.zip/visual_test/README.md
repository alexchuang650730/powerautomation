# PowerAutomation 端到端视觉化测试框架

本目录包含PowerAutomation项目的端到端视觉化测试框架，用于验证PPT生成功能的正确性和一致性。

## 目录结构

```
visual_test/
├── README.md                 # 本文档
├── ppt_task_manager.py       # 测试用PPT任务管理器
├── test_ppt_generation.py    # 端到端测试脚本
├── ppt_to_image.py           # PPT转图片工具
├── requirements.txt          # 依赖库列表
└── static/                   # 静态资源目录
    └── templates/            # PPT模板目录
        └── 专业简历.pptx      # 测试用PPT模板
```

## 测试框架特点

1. **跨平台支持**：支持Windows、macOS和Linux
2. **视觉化验证**：将PPT转换为图片，便于视觉化比对
3. **自动化测试**：一键执行端到端测试
4. **详细日志**：记录测试过程和结果
5. **模板兼容性**：验证不同模板的兼容性

## 使用方法

### 安装依赖

```bash
pip install -r requirements.txt
```

### 运行测试

```bash
python test_ppt_generation.py
```

### 生成视觉化测试结果

```bash
python ppt_to_image.py test_output/test_generated_ppt.pptx
```

## 测试内容

1. **模板加载测试**：验证模板加载是否正确
2. **内容提取测试**：验证从思维导图节点提取内容是否正确
3. **幻灯片生成测试**：验证幻灯片生成是否正确
4. **样式继承测试**：验证样式是否正确继承自模板
5. **背景颜色测试**：验证背景颜色是否正确
6. **文本可见性测试**：验证文本是否可见且清晰

## 测试结果解读

测试脚本执行后，会在`test_output`目录下生成以下文件：

- `test_generated_ppt.pptx`：生成的PPT文件
- `test_ppt_generation_YYYYMMDD_HHMMSS.log`：测试日志
- `images/`：PPT转换的图片文件（如果执行了`ppt_to_image.py`）

## 常见问题排查

1. **黑色背景问题**：如果幻灯片出现黑色背景，检查模板背景复制逻辑
2. **文本不可见问题**：检查文本颜色与背景对比度
3. **样式不一致问题**：检查模板样式继承逻辑
4. **内容缺失问题**：检查内容提取逻辑

## 扩展测试

如需添加新的测试用例，可以：

1. 在`test_ppt_generation.py`中添加新的测试数据
2. 在`static/templates/`目录中添加新的模板
3. 修改`ppt_task_manager.py`中的测试逻辑

## 注意事项

- 测试前确保已安装所有依赖库
- 不同操作系统可能有细微的渲染差异
- 建议使用相同版本的python-pptx库进行测试
