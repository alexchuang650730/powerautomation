"""
通用智能体模块 - General Agent

提供对话、任务执行和项目管理功能，作为PowerAutomation平台的通用入口。
通过MCP规划器和MCP头脑风暴器调用开发工具模块和已有工具。
"""
