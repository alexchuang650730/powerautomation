"""
PPT Agent 模块初始化文件
确保PPT Agent可以被正确导入和识别
"""

from .ppt_agent_features import PptAgentFeatures

__all__ = ['PptAgentFeatures']
